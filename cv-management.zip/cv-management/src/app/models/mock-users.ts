import {User} from 'src/app/models/user';

export const USERS: User[] = [
    { id: 1, name: 'Evgeni', lastName: 'Stoykov', image: '', description: 'Cool' },
    { id: 2, name: 'John', lastName: "Doe", image: '', description: 'The Java Expert'},
    { id: 3, name: 'Mike', lastName: 'Brown', image: '', description: 'Google Type Person' }
];