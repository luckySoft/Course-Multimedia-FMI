export class User {
    id: number;
    name: string;
    lastName: string;
    image: string;
    description?: string;
}